"""
Antes de ejecutar el test, ejecutar el siguiente comando para instalar la libreria necesaria

pip install selenium webdriver-manager
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
import time


# Configuración automática del WebDriver
driver = webdriver.Chrome()

# Maximizar la ventana del navegador
driver.maximize_window()

# Abrir url en el navegador
driver.get('http://localhost:3001/login')

# Acciones para interactuar con el navegador
driver.find_element(By.XPATH, "//input[@id='Email']").send_keys("admin@gmail.com")
driver.find_element(By.XPATH, "//input[@id='pass']").send_keys("admin123")
time.sleep(4)
driver.find_element(By.XPATH, "//i[@id='show_password']").click()
driver.find_element(By.XPATH, "//input[@type='submit']").click()
time.sleep(4)

driver.quit()

print("Prueba visual completada")
